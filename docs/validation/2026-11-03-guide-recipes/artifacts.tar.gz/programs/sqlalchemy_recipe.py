import os
import uuid
import sqlalchemy as sa
uri = os.environ.get("FLIGHT_URI", "grpc://localhost:18816")
engine = sa.create_engine("adbc+flightsql://" + uri.removeprefix("grpc://") + "?tls=false",
                          connect_args={"autocommit": True})
name = "guide_" + uuid.uuid4().hex
try:
    with engine.connect() as conn:
        source = conn.exec_driver_sql(
            "SELECT id, label, amount FROM guide_live_20261103_d2f23049d00d ORDER BY id").mappings().all()
        try:
            conn.exec_driver_sql(f'CREATE TABLE "{name}" (id BIGINT NOT NULL, label VARCHAR, amount DOUBLE)').close()
            for row in source:
                conn.exec_driver_sql(f'INSERT INTO "{name}" (id, label, amount) VALUES (?, ?, ?)',
                                     (row["id"], row["label"], row["amount"] * 2)).close()
            received = conn.exec_driver_sql(f'SELECT * FROM "{name}" ORDER BY id').mappings().all()
            assert [row["amount"] for row in received] == [3.0, 5.0, 7.0]
            print(received)
        finally:
            conn.exec_driver_sql(f'DROP TABLE IF EXISTS "{name}"').close()
finally:
    engine.dispose()
