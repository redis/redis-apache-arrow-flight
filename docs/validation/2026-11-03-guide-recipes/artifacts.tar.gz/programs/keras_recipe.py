import os
import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql

uri = os.environ.get("FLIGHT_URI", "grpc://localhost:18816")
with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT id, label, amount FROM guide_live_20261103_d2f23049d00d ORDER BY id")
    source = cur.fetch_arrow_table()

# Set the backend before importing Keras.
os.environ["KERAS_BACKEND"] = "tensorflow"
import numpy as np
import keras
values = np.asarray(source["amount"].to_pylist(), dtype=np.float32).reshape(-1, 1)
model = keras.Sequential([keras.layers.Input(shape=(1,)), keras.layers.Dense(1)])
model.layers[0].set_weights([np.array([[2.0]], dtype=np.float32),
                            np.array([1.0], dtype=np.float32)])
predicted = model(values, training=False).numpy().flatten()
output = pa.table({"id": source["id"], "prediction": predicted})

# Write the tool's output through Flight SQL, then verify the stored values.
name = "guide_" + uuid.uuid4().hex
with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
    try:
        cur.adbc_ingest(name, output, mode="create")
        cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
        received = cur.fetch_arrow_table()
        assert received.equals(output)
        print(received)
    finally:
        cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.fetch_arrow_table()
