import os
import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql

uri = os.environ.get("FLIGHT_URI", "grpc://localhost:18816")
with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT id, label, amount FROM guide_live_20261103_d2f23049d00d ORDER BY id")
    source = cur.fetch_arrow_table()

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
import torch
from tokenizers import Tokenizer
from tokenizers.models import WordLevel
from tokenizers.pre_tokenizers import Whitespace
from transformers import BertConfig, BertModel, PreTrainedTokenizerFast
local = Tokenizer(WordLevel({"[UNK]": 0, "[PAD]": 1, "one": 2, "three": 3}, unk_token="[UNK]"))
local.pre_tokenizer = Whitespace()
tokenizer = PreTrainedTokenizerFast(tokenizer_object=local, unk_token="[UNK]", pad_token="[PAD]")
batch = tokenizer([value or "" for value in source["label"].to_pylist()],
                  padding=True, return_tensors="pt")
model = BertModel(BertConfig(vocab_size=4, hidden_size=16, num_hidden_layers=1,
                             num_attention_heads=2, intermediate_size=32)).eval()
with torch.no_grad():
    vectors = model(**batch).last_hidden_state[:, 0, :]
# SQL example stores a scalar; named Flight datasets can preserve vector columns.
output = pa.table({"id": source["id"], "feature": vectors[:, 0].tolist()})

# Write the tool's output through Flight SQL, then verify the stored values.
name = "guide_" + uuid.uuid4().hex
with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
    try:
        cur.adbc_ingest(name, output, mode="create")
        cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
        received = cur.fetch_arrow_table()
        assert received.equals(output)
        print(received)
    finally:
        cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.fetch_arrow_table()
