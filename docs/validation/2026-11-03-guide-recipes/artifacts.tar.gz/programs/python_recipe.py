import adbc_driver_flightsql.dbapi as sql

with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT id, label, amount FROM guide_live_20261103_d2f23049d00d WHERE id >= ? ORDER BY id", (2,))
    print(cur.fetch_arrow_table())


import uuid
import pyarrow as pa
import pyarrow.flight as flight

client = flight.connect("grpc://localhost:18816")
name = "guide_" + uuid.uuid4().hex
desc = flight.FlightDescriptor.for_path(name)
try:
    source = pa.table({"id": [1, 2], "embedding": [[0.1, 0.2], [0.3, 0.4]]})
    writer, metadata = client.do_put(desc, source.schema)
    with writer:
        writer.write_table(source)
        writer.done_writing()
        print(metadata.read())  # Consume the upload acknowledgement.
    info = client.get_flight_info(desc)
    received = pa.concat_tables([
        client.do_get(ep.ticket).read_all() for ep in info.endpoints
    ])
    assert received.equals(source)
finally:
    try:
        list(client.do_action(flight.Action("drop_dataset", name.encode())))
    finally:
        client.close()


import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql

output = pa.table({"id": [1, 2], "amount": [2.0, 4.0]})
name = "guide_" + uuid.uuid4().hex
with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    try:
        cur.adbc_ingest(name, output, mode="create")
        cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
        assert cur.fetch_arrow_table().equals(output)
    finally:
        cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.fetch_arrow_table()
