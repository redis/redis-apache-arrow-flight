import os
import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql

uri = os.environ.get("FLIGHT_URI", "grpc://localhost:18816")
with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT id, label, amount FROM guide_live_20261103_d2f23049d00d ORDER BY id")
    source = cur.fetch_arrow_table()

import tensorflow as tf
values = tf.constant(source["amount"].to_pylist(), dtype=tf.float32)
dataset = tf.data.Dataset.from_tensor_slices(values).batch(2)
predicted = []
for batch in dataset:
    predicted.extend((batch * 2 + 1).numpy().tolist())
output = pa.table({"id": source["id"], "prediction": predicted})

# Write the tool's output through Flight SQL, then verify the stored values.
name = "guide_" + uuid.uuid4().hex
with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
    try:
        cur.adbc_ingest(name, output, mode="create")
        cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
        received = cur.fetch_arrow_table()
        assert received.equals(output)
        print(received)
    finally:
        cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.fetch_arrow_table()
