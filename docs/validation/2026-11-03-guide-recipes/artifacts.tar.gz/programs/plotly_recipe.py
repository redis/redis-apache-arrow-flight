import os
import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql

uri = os.environ.get("FLIGHT_URI", "grpc://localhost:18816")
with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT id, label, amount FROM guide_live_20261103_d2f23049d00d ORDER BY id")
    source = cur.fetch_arrow_table()

import plotly.graph_objects as go
figure = go.Figure(go.Scatter(x=source["id"].to_pylist(),
                              y=source["amount"].to_pylist(), mode="lines+markers"))
figure.write_html("flight-plot.html", include_plotlyjs=True)
# Persist the plotted points, not the HTML artifact.
output = pa.table({"id": list(figure.data[0].x), "amount": list(figure.data[0].y)})

# Write the tool's output through Flight SQL, then verify the stored values.
name = "guide_" + uuid.uuid4().hex
with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
    try:
        cur.adbc_ingest(name, output, mode="create")
        cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
        received = cur.fetch_arrow_table()
        assert received.equals(output)
        print(received)
    finally:
        cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.fetch_arrow_table()
