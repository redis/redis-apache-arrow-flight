import duckdb
import adbc_driver_flightsql.dbapi as sql

with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT id, label, amount FROM guide_live_20261103_d2f23049d00d ORDER BY id")
    table = cur.fetch_arrow_table()

with duckdb.connect() as local:
    local.register("redis_rows", table)
    result = local.execute("SELECT COUNT(*), SUM(amount) FROM redis_rows").fetchone()
    assert result == (3, 7.5)
    print(result)


import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql

import duckdb
with duckdb.connect() as local:
    output = local.sql("SELECT 1::BIGINT AS id, 2.0::DOUBLE AS amount").to_arrow_table()
name = "guide_" + uuid.uuid4().hex
with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    try:
        cur.adbc_ingest(name, output, mode="create")
        cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
        assert cur.fetch_arrow_table().equals(output)
    finally:
        cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.fetch_arrow_table()
