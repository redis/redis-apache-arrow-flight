import os
import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql
from pyspark.sql import SparkSession
uri = os.environ.get("FLIGHT_URI", "grpc://localhost:18816")
jar = os.path.abspath(os.environ["FLIGHT_JDBC_JAR"])
spark = (SparkSession.builder.master("local[2]").appName("flight-guide")
    .config("spark.jars", jar)
    .config("spark.driver.extraJavaOptions", "--add-opens=java.base/java.nio=ALL-UNNAMED")
    .config("spark.executor.extraJavaOptions", "--add-opens=java.base/java.nio=ALL-UNNAMED")
    .getOrCreate())
try:
    frame = spark.read.jdbc(
        "jdbc:arrow-flight-sql://" + uri.removeprefix("grpc://") + "/?useEncryption=false",
        "guide_live_20261103_d2f23049d00d", properties={"driver": "org.apache.arrow.driver.jdbc.ArrowFlightJdbcDriver"})
    frame.show()
    transformed = frame.selectExpr("id", "amount * 2 AS amount").orderBy("id")
    # Small local bridge: collect rows before writing through ADBC.
    output = pa.Table.from_pylist([row.asDict() for row in transformed.collect()])
    # Write the tool's output through Flight SQL, then verify the stored values.
    name = "guide_" + uuid.uuid4().hex
    with sql.connect(uri, autocommit=True) as conn, conn.cursor() as cur:
        try:
            cur.adbc_ingest(name, output, mode="create")
            cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
            received = cur.fetch_arrow_table()
            assert received.equals(output)
            print(received)
        finally:
            cur.execute(f'DROP TABLE IF EXISTS "{name}"')
            cur.fetch_arrow_table()
finally:
    spark.stop()
