import os
import uuid
import pyarrow as pa
import adbc_driver_flightsql
from dagster import asset, materialize
from dagster_adbc import ADBCResource

@asset
def flight_copy(flight: ADBCResource) -> int:
    name = "guide_" + uuid.uuid4().hex
    with flight.get_connection() as conn, conn.cursor() as cur:
        cur.execute("SELECT id, label, amount FROM guide_live_20261103_d2f23049d00d ORDER BY id")
        source = cur.fetch_arrow_table()
        output = pa.table({"id": source["id"],
                           "amount": [value * 2 for value in source["amount"].to_pylist()]})
        try:
            cur.adbc_ingest(name, output, mode="create")
            cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
            assert cur.fetch_arrow_table().equals(output)
        finally:
            cur.execute(f'DROP TABLE IF EXISTS "{name}"')
            cur.fetch_arrow_table()
    return output.num_rows

if __name__ == "__main__":
    resource = ADBCResource(driver=adbc_driver_flightsql._driver_path(),
        uri=os.environ.get("FLIGHT_URI", "grpc://localhost:18816"), autocommit=True)
    result = materialize([flight_copy], resources={"flight": resource})
    assert result.success
    assert result.output_for_node("flight_copy") == 3
