import polars as pl
import adbc_driver_flightsql.dbapi as sql

with sql.connect("grpc://localhost:18816", autocommit=True) as conn:
    query = "SELECT * FROM guide_live_20261103_d2f23049d00d ORDER BY id"
    frame = pl.read_database(query, conn)
    print(frame)
    assert frame["id"].to_list() == [1, 2, 3]
    assert frame["label"].null_count() == 1
    for batch in pl.read_database(query, conn, iter_batches=True, batch_size=2):
        print(batch)


import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql

import polars as pl
output = pl.DataFrame({"id": [1, 2], "amount": [2.0, 4.0]}).to_arrow()
name = "guide_" + uuid.uuid4().hex
with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    try:
        cur.adbc_ingest(name, output, mode="create")
        cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
        assert cur.fetch_arrow_table().equals(output)
    finally:
        cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.fetch_arrow_table()
