import pandas as pd
import adbc_driver_flightsql.dbapi as sql

with sql.connect("grpc://localhost:18816", autocommit=True) as conn:
    frame = pd.read_sql("SELECT * FROM guide_live_20261103_d2f23049d00d ORDER BY id", conn)
    print(frame)
    assert frame.id.tolist() == [1, 2, 3]
    assert pd.isna(frame.loc[1, "label"])


with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT * FROM guide_live_20261103_d2f23049d00d WHERE id >= ? ORDER BY id", (2,))
    selected = cur.fetch_arrow_table().to_pandas()
    assert selected.id.tolist() == [2, 3]


import uuid
import pyarrow as pa
import adbc_driver_flightsql.dbapi as sql

import pandas as pd
output = pa.Table.from_pandas(pd.DataFrame({"id": [1, 2], "amount": [2.0, 4.0]}),
                            preserve_index=False)
name = "guide_" + uuid.uuid4().hex
with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    try:
        cur.adbc_ingest(name, output, mode="create")
        cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
        assert cur.fetch_arrow_table().equals(output)
    finally:
        cur.execute(f'DROP TABLE IF EXISTS "{name}"')
        cur.fetch_arrow_table()
