import os,sqlite3,secrets,json
from pathlib import Path
out=Path('/tmp/flight-recipes-live'); state=out/'superset';state.mkdir(exist_ok=True)
with sqlite3.connect('file:/tmp/flight-superset7-20261101/metadata.db?mode=ro',uri=True) as source,sqlite3.connect(state/'metadata.db') as target:
    source.backup(target)
config=state/'superset_config.py';config.write_text('import os\nSECRET_KEY=os.environ["SUPERSET_RECIPE_SECRET"]\nSQLALCHEMY_DATABASE_URI="sqlite:////tmp/flight-recipes-live/superset/metadata.db"\nWTF_CSRF_ENABLED=False\nTESTING=True\n')
os.environ['SUPERSET_CONFIG_PATH']=str(config);os.environ['SUPERSET_RECIPE_SECRET']=secrets.token_urlsafe(48)
from superset.app import create_app
from superset import security_manager
app=create_app(); password=secrets.token_urlsafe(32)
with app.app_context():
    user=security_manager.add_user('guide_live','Guide','Live','guide-live@example.invalid',security_manager.find_role('Admin'),password=password)
    assert user
client=app.test_client();login=client.post('/api/v1/security/login',json={'username':'guide_live','password':password,'provider':'db','refresh':True});assert login.status_code==200
headers={'Authorization':'Bearer '+login.get_json()['access_token']}
def call(method,path,payload):
    r=getattr(client,method)(path,json=payload,headers=headers)
    assert r.status_code in [200,201],(path,r.status_code,r.get_json())
    return r.get_json()
extra=json.dumps({'engine_params':{'connect_args':{'autocommit':True}}})
created=call('post','/api/v1/database/',{'database_name':'Guide recipes live','sqlalchemy_uri':'adbc+flightsql://localhost:18816?tls=false','extra':extra,'expose_in_sqllab':True,'allow_dml':True})
dbid=created['id'];table=(out/'fixture.txt').read_text()
def sql(label,query,expected=None):
    r=call('post','/api/v1/sqllab/execute/',{'database_id':dbid,'sql':query,'schema':'public','runAsync':False,'queryLimit':100})
    assert r['status']=='success',r
    if expected is not None:assert r['data']==expected,r
    print(json.dumps({'check':label,'status':'PASS','rows':r['data']},default=str),flush=True)
sql('guide ordered read',f'SELECT id, label, amount FROM {table} ORDER BY id',[{'id':1,'label':'one','amount':1.5},{'id':2,'label':None,'amount':2.5},{'id':3,'label':'three','amount':3.5}])
try:
    sql('guide INSERT',f"INSERT INTO {table} (id, label, amount) VALUES (99, 'guide', 9.5)")
    sql('guide INSERT read-back',f'SELECT * FROM {table} WHERE id = 99',[{'id':99,'label':'guide','amount':9.5}])
finally:
    sql('guide DELETE',f'DELETE FROM {table} WHERE id = 99')
    sql('guide DELETE read-back',f'SELECT * FROM {table} WHERE id = 99',[])
print('PASS Superset 7 development SQL Lab APIs through Flask test client; browser and metadata discovery not tested',flush=True)
