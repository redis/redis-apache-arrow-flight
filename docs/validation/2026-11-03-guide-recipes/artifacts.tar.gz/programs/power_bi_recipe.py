import adbc_driver_flightsql.dbapi as sql
with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("SELECT id FROM guide_live_20261103_d2f23049d00d WHERE id = 99")
    assert cur.fetch_arrow_table().num_rows == 0, "choose a different unused id"
    cur.execute("INSERT INTO guide_live_20261103_d2f23049d00d (id, label, amount) VALUES (99, 'guide', 9.5)")
    cur.fetch_arrow_table()
    cur.execute("SELECT label, amount FROM guide_live_20261103_d2f23049d00d WHERE id = 99")
    assert cur.fetch_arrow_table().to_pylist() == [{"label": "guide", "amount": 9.5}]


import adbc_driver_flightsql.dbapi as sql
with sql.connect("grpc://localhost:18816", autocommit=True) as conn, conn.cursor() as cur:
    cur.execute("DELETE FROM guide_live_20261103_d2f23049d00d WHERE id = 99")
    cur.fetch_arrow_table()
    cur.execute("SELECT id FROM guide_live_20261103_d2f23049d00d WHERE id = 99")
    assert cur.fetch_arrow_table().num_rows == 0
