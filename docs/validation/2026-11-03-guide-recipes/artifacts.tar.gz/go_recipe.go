package main

import (
    "context"
"github.com/google/uuid"
"github.com/apache/arrow-go/v18/arrow/array"
    "fmt"
    "log"

    "github.com/apache/arrow-go/v18/arrow/flight/flightsql"
    "google.golang.org/grpc"
    "google.golang.org/grpc/credentials/insecure"
)

func main() {
    if err := run(); err != nil { log.Fatal(err) }
}

func run() error {
    ctx := context.Background()
    client, err := flightsql.NewClient("localhost:18816", nil, nil,
        grpc.WithTransportCredentials(insecure.NewCredentials()))
    if err != nil { return err }
    defer client.Close()
name := "guide_" + uuid.NewString()
name = "\"" + name + "\"" // Quote the UUID's hyphens as part of the identifier.
if _, err := client.ExecuteUpdate(ctx, "CREATE TABLE " + name + " (id BIGINT, amount DOUBLE)"); err != nil {
    return err
}
defer func() {
    if _, err := client.ExecuteUpdate(ctx, "DROP TABLE " + name); err != nil { log.Print(err) }
}()
if _, err := client.ExecuteUpdate(ctx, "INSERT INTO " + name + " VALUES (1, 2.5)"); err != nil {
    return err
}
written, err := client.Execute(ctx, "SELECT amount FROM " + name)
if err != nil { return err }
count := int64(0)
for _, ep := range written.Endpoint {
    reader, err := client.DoGet(ctx, ep.Ticket)
    if err != nil { return err }
    for reader.Next() {
        batch := reader.RecordBatch()
        amounts, ok := batch.Column(0).(*array.Float64)
        if !ok { reader.Release(); return fmt.Errorf("expected DOUBLE amount") }
        for i := 0; i < amounts.Len(); i++ {
            if amounts.IsNull(i) || amounts.Value(i) != 2.5 {
                reader.Release(); return fmt.Errorf("write/read-back mismatch")
            }
        }
        count += batch.NumRows()
    }
    err = reader.Err()
    reader.Release()
    if err != nil { return err }
}
if count != 1 { return fmt.Errorf("expected one written row, got %d", count) }

    info, err := client.Execute(ctx, "SELECT * FROM guide_live_20261103_d2f23049d00d ORDER BY id")
    if err != nil { return err }
    for _, ep := range info.Endpoint {
        reader, err := client.DoGet(ctx, ep.Ticket)
        if err != nil { return err }
        for reader.Next() { fmt.Println(reader.RecordBatch()) }
        err = reader.Err()
        reader.Release()
        if err != nil { return err }
    }
    return nil
}
