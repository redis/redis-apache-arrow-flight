import java.sql.*;
public class JdbcRecipe {
  public static void main(String[] args) throws Exception {
    String table = args[0];
    try (Connection conn = DriverManager.getConnection("jdbc:arrow-flight-sql://localhost:18816/?useEncryption=false"); Statement stmt = conn.createStatement()) {
      conn.setAutoCommit(true);
      try (ResultSet rows = stmt.executeQuery("SELECT COUNT(*), SUM(amount) FROM " + table)) {
        if (!rows.next() || rows.getLong(1) != 3 || rows.getDouble(2) != 7.5) throw new AssertionError("aggregate");
      }
      try {
        stmt.executeUpdate("INSERT INTO " + table + " (id, label, amount) VALUES (99, 'guide', 9.5)");
        check(stmt, table, 9.5);
        stmt.executeUpdate("UPDATE " + table + " SET amount = 10.5 WHERE id = 99");
        check(stmt, table, 10.5);
      } finally { stmt.executeUpdate("DELETE FROM " + table + " WHERE id = 99"); }
      try (ResultSet rows = stmt.executeQuery("SELECT * FROM " + table + " WHERE id = 99")) {
        if (rows.next()) throw new AssertionError("delete read-back");
      }
      System.out.println("PASS guide JDBC SQL: aggregate, INSERT/read, UPDATE/read, DELETE/read; driver scope only");
    }
  }
  static void check(Statement stmt, String table, double amount) throws Exception {
    try (ResultSet rows = stmt.executeQuery("SELECT * FROM " + table + " WHERE id = 99")) {
      if (!rows.next() || rows.getLong("id") != 99 || !"guide".equals(rows.getString("label")) || rows.getDouble("amount") != amount || rows.next()) throw new AssertionError("write read-back");
    }
  }
}
