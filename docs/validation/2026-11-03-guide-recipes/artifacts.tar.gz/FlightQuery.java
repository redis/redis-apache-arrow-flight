import java.sql.*;

public class FlightQuery {
    public static void main(String[] args) throws Exception {
        String url = "jdbc:arrow-flight-sql://localhost:18816/?useEncryption=false";
        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT id, label FROM guide_live_20261103_d2f23049d00d WHERE id >= ? ORDER BY id")) {
            stmt.setInt(1, 2);
            try (ResultSet rows = stmt.executeQuery()) {
                while (rows.next()) {
                    System.out.println(rows.getLong(1) + ": " + rows.getString(2));
                }
            }
        }
    }
}
