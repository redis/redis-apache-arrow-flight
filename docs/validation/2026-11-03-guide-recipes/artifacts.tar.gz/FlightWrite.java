import java.sql.*;
import java.util.UUID;

public class FlightWrite {
    public static void main(String[] args) throws Exception {
        String name = "guide_" + UUID.randomUUID().toString().replace("-", "");
        String url = "jdbc:arrow-flight-sql://localhost:18816/?useEncryption=false";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            conn.setAutoCommit(true);
            try {
                stmt.executeUpdate("CREATE TABLE " + name + " (id BIGINT, amount DOUBLE)");
                stmt.executeUpdate("INSERT INTO " + name + " VALUES (1, 2.5)");
                try (ResultSet rows = stmt.executeQuery("SELECT * FROM " + name)) {
                    if (!rows.next() || rows.getLong("id") != 1 || rows.getDouble("amount") != 2.5
                        || rows.next()) throw new AssertionError("write/read-back mismatch");
                }
            } finally {
                stmt.executeUpdate("DROP TABLE IF EXISTS " + name);
            }
        }
    }
}
