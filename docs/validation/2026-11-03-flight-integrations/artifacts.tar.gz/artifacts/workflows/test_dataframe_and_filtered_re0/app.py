import os
import streamlit as st
import adbc_driver_flightsql.dbapi as dbapi

minimum = st.number_input("Minimum id", min_value=1, max_value=3, value=1)
with dbapi.connect(os.environ["FLIGHT_URI"], autocommit=True) as conn, conn.cursor() as cur:
    name = os.environ["REDIS_ADBC_TEST_TABLE"]
    cur.execute(f'SELECT * FROM "{name}" WHERE id >= ? ORDER BY id', (minimum,))
    data = cur.fetch_arrow_table()
st.dataframe(data)
st.metric("Rows", data.num_rows)
