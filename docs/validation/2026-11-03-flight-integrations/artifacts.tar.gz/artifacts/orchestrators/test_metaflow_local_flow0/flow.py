import os
from metaflow import FlowSpec, step

class RedisADBCCandidateFlow(FlowSpec):
    @step
    def start(self):
        import adbc_driver_flightsql.dbapi as dbapi
        with dbapi.connect(os.environ["FLIGHT_URI"], autocommit=True) as conn, conn.cursor() as cur:
            name = os.environ["REDIS_ADBC_TEST_TABLE"]
            cur.execute(f'SELECT * FROM "{name}" ORDER BY id')
            self.rows = cur.fetch_arrow_table().to_pylist()
        self.next(self.end)

    @step
    def end(self):
        assert [r["id"] for r in self.rows] == [1, 2, 3]
        assert [r["label"] for r in self.rows] == ["alpha", None, "雪"]
        assert [r["active"] for r in self.rows] == [True, None, False]
        print("REDIS_ADBC_METAFLOW_OK")

if __name__ == "__main__":
    RedisADBCCandidateFlow()
